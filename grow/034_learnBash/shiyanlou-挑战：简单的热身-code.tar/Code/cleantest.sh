#!/bin/sh

# Clear the contents of the current dirctory file named test.sh
cat /dev/null > ./test.sh
