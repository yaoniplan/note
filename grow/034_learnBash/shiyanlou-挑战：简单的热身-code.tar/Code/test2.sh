#!/bin/sh

# Save text "Hello Shiyanlou" to file named "my.txt"
echo "Hello Shiyanlou" > my.txt
