#!/bin/sh

# Output "Hello Shiyanlou!"
echo "Hello Shiyanlou!"
