#!/bin/bash
# This is a comment
#echo Hello World
echo "hello world" > my.txt
