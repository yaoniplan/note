#! /bin/sh

var1=5
var2=23skidoo

echo $var1  # 5
echo $var2  # 23skidoo
