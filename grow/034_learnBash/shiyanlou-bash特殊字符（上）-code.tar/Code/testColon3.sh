#! /bin/sh

condition=5

if [ $condition -gt 0 ] # "-gt" is "greater than"
then : # Do nothing, exit
else
    echo "$condition"
fi
