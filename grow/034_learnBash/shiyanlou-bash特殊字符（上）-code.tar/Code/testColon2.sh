#! /bin/sh

while true
do
    echo "endless loop"
done
