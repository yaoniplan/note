#! /bin/sh

while :
do
    echo "endless loop"
done
