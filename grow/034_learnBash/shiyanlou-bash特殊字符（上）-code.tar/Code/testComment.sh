#! /bin/sh

echo "The # here does not begin a comment."
echo 'The # here does not begin a comment.'
echo The \# here does not begin a comment.
echo The # The first comment
echo $(( 2#101011 ))    # Number system conversion (Use binary represetation), isn't a comment, double brackets indicate the treatment of numbers

# Welcome to the Shiyanlou to visit and study
