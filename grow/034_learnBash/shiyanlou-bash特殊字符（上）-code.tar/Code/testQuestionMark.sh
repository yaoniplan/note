#! /bin/sh

a=10
(( t=a<50?8:9 ))
echo $t
